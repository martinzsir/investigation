#!/usr/bin/env python3
"""确定性采集：产出研判报告的「第二段/第五段」事实块（已脱敏）。

设计要点：
  1. 纯确定性——不调用任何 LLM，数字来自内核计算或声明文件；
  2. per-case——只消费指定案件的数据根，绝不读全局产物；
  3. 脱敏前置——输出即脱敏，外部 Agent 拿到的已是安全载荷；
  4. 降级不静默——取不到的项写进 "降级" 数组，报告必须如实标注。

用法：
    python gather_evidence.py --case C001 --clue L3 --out evidence.json
    python gather_evidence.py --case C001 --demo
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

# ----------------------------------------------------------------------
# 项目根定位
# ----------------------------------------------------------------------


def find_project_root(explicit: str | None = None) -> Path:
    """定位侦查内核项目根（含 core/ 与 ontology/ 的目录）。"""
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if not (p / "core").exists():
            raise SystemExit(f"--project-root 不像项目根（缺 core/）：{p}")
        return p
    env = Path.cwd()
    for base in (env, *env.parents):
        if (base / "core").exists() and (base / "ontology").exists():
            return base
    raise SystemExit(
        "未找到项目根（未发现同时含 core/ 与 ontology/ 的目录）。\n"
        "请用 --project-root 指定，或设置环境变量 SUNZI_ROOT。"
    )


# ----------------------------------------------------------------------
# 脱敏
# ----------------------------------------------------------------------

# 按 llm_policy.json 的 pii_redaction：id_card/phone/bank_card = redact
#
# 注意：不能用 \b 作边界——Python re 默认 Unicode 模式下中文属 \w，
# "身份证110101199003071234" 中「证」与「1」之间 \b 不成立，会漏脱敏。
# 统一改用 (?<!\d) / (?!\d) 数字边界（实测修复）。
_PII_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"), "[身份证已遮蔽]"),
    (re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"), "[手机号已遮蔽]"),
    (re.compile(r"(?<!\d)\d{16,19}(?!\d)"), "[银行卡号已遮蔽]"),
]


def redact(obj: Any) -> Any:
    """递归脱敏：对字符串应用 PII 正则，容器递归。"""
    if isinstance(obj, str):
        out = obj
        for pat, repl in _PII_PATTERNS:
            out = pat.sub(repl, out)
        return out
    if isinstance(obj, dict):
        return {k: redact(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    return obj


# ----------------------------------------------------------------------
# 采集
# ----------------------------------------------------------------------


def load_jians(root: Path, pack: str) -> dict[str, Any]:
    """读五间声明（间类名 / 权重 / 密级）。"""
    f = root / "ontology" / pack / "jians.json"
    if not f.exists():
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_rules(root: Path, pack: str) -> list[dict[str, Any]]:
    """读规则手册全集（确定性，供第五段引用）。"""
    f = root / "ontology" / pack / "rules.json"
    if not f.exists():
        return []
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return []
    items = data.get("rules", data) if isinstance(data, dict) else data
    out = []
    for r in items if isinstance(items, list) else []:
        out.append({
            "id": r.get("id", ""),
            "名称": r.get("name", r.get("title", "")),
            "判据": r.get("condition", r.get("rule_text", "")),
            "间类": r.get("jian_types", r.get("jian", [])),
        })
    return out


def collect_cross(root: Path, pack: str, degraded: list[str]) -> dict[str, Any]:
    """五间覆盖 + 交叉等级 + 覆盖缺口（确定性）。"""
    jians = load_jians(root, pack)
    declared = []
    for item in jians.get("jians", []) if isinstance(jians, dict) else []:
        declared.append({
            "名称": item.get("name", ""),
            "权重": item.get("weight"),
            "密级": item.get("default_clearance"),
            "数据源": item.get("source_object_types", []),
        })

    hit: dict[str, int] = {}
    level = None
    cross_ok = True
    try:
        sys.path.insert(0, str(root))
        from core import Store  # type: ignore
        from core.functions import invoke_function  # type: ignore

        store = Store(root=str(root / "data"))
        r = invoke_function(store, "jian_cross_level")["result"]
        hit = {k: len(v) for k, v in (r.get("rows") or {}).items()} \
            if isinstance(r.get("rows"), dict) else {}
        for row in (r.get("rows") or []) if isinstance(r.get("rows"), list) else []:
            hit[row.get("间类", "")] = row.get("命中数", 0)
        level = r.get("交叉等级")
    except Exception as exc:  # 内核不可用时降级，不静默
        cross_ok = False
        degraded.append(f"五间交叉不可用（{type(exc).__name__}）：未 BUILD 或内核未就绪")

    covered = {k for k, v in hit.items() if v}

    # 降级时不得把"算不出来"呈现为"全部未覆盖"——后者会被误读为真实结论。
    if not cross_ok:
        missing: list[str] | None = None
    else:
        missing = sorted({d["名称"] for d in declared} - covered) if declared else []

    return {
        "五间声明": declared,
        "命中间类": sorted(covered),
        "命中计数": hit,
        "交叉等级": level,
        "覆盖缺口": missing,
        "覆盖缺口已知": cross_ok,
        "等级规则": "单源=观察 / 双源=线索 / 三源以上=可立案依据候选",
    }


def collect_overpass(root: Path, degraded: list[str]) -> list[dict[str, Any]]:
    """图库两跳过桥路径（不可用时降级，绝不伪造路径）。"""
    try:
        sys.path.insert(0, str(root))
        from core import Store  # type: ignore
        from core.graph import GraphBackend, overpass_two_hop_sql  # type: ignore

        store = Store(root=str(root / "data"))
        return overpass_two_hop_sql(store) or []
    except Exception as exc:
        degraded.append(f"过桥路径不可用（{type(exc).__name__}）：图库未构建或非必需")
        return []


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------


def main() -> int:
    ap = argparse.ArgumentParser(description="研判报告确定性采集（已脱敏）")
    ap.add_argument("--case", required=True, help="案件 ID")
    ap.add_argument("--clue", default="", help="线索 ID（可空=全案件）")
    ap.add_argument("--pack", default="default", help="本体包")
    ap.add_argument("--out", default="", help="输出 JSON 路径（默认 stdout）")
    ap.add_argument("--project-root", default="", help="侦查内核项目根")
    ap.add_argument("--demo", action="store_true", help="降级演示（无案件库也可跑）")
    args = ap.parse_args()

    root = find_project_root(args.project_root or None)
    degraded: list[str] = []

    # 案件数据版本（读不到则降级，不冒充 0）
    version: int | None = None
    case_duckdb = root / "cases" / args.case
    if case_duckdb.exists():
        vs = sorted(
            (int(p.stem[1:]) for p in case_duckdb.glob("v*.duckdb") if p.stem[1:].isdigit()),
            reverse=True,
        )
        version = vs[0] if vs else None
    else:
        degraded.append(f"案件库不存在：{case_duckdb}（未 BUILD 或 case_id 有误）")

    if version is None and not args.demo:
        degraded.append("未解析到 data_version：报告将缺少数据版本锚点")

    evidence = {
        "case_id": args.case,
        "clue_id": args.clue,
        "pack": args.pack,
        "data_version": version,
        "确定性块": {
            "证据充分性": collect_cross(root, args.pack, degraded),
            "关联核验": {
                "过桥路径": collect_overpass(root, degraded),
                "规则手册": load_rules(root, args.pack),
            },
        },
        "降级": degraded,
        "脱敏": True,
        "生成方式": "deterministic（无 LLM 参与）",
    }

    safe = redact(evidence)
    text = json.dumps(safe, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"已写入 {args.out}（降级项 {len(degraded)} 条）", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
