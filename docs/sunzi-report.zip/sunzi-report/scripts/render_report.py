#!/usr/bin/env python3
"""渲染研判报告：十段契约 + 三类受众形态 + md/docx 导出。

关键约束：
  - 第二段（证据充分性）与第五段（关联核验）**由 evidence.json 确定性渲染**，
    即便 sections.json 提供了同名段也忽略（防 LLM 改写数字）；
  - 降级项非空时，在报告头部生成「降级声明」块，不静默；
  - C 类（移送）剔除推断与待核实段，AI 不做定性。

用法：
    python render_report.py --evidence evidence.json --sections sections.json \
        --type A --format md --out 研判报告.md
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

# 十段契约：key → 中文标题
SECTION_TITLES: list[tuple[str, str]] = [
    ("overview", "一、线索概况"),
    ("sufficiency", "二、证据充分性"),
    ("rules", "三、命中规则与判据"),
    ("facts", "四、事实与依据"),
    ("correlation", "五、关联核验"),
    ("inferences", "六、研判推断"),
    ("pending", "七、待核实事项"),
    ("evidence", "八、书证清单"),
    ("sources", "九、数据源清单"),
]

# 确定性段（只由 evidence 渲染，Agent 不得改写）
DETERMINISTIC = {"sufficiency", "correlation"}

# 各类型保留的段（空集 = 全部）
TYPE_KEEP: dict[str, set[str] | None] = {
    "A": None,  # 全量
    "B": {"overview", "sufficiency", "rules", "facts", "pending",
          "evidence", "sources"},  # 去推断、去关联核验细节
    "C": {"overview", "sufficiency", "rules", "facts",
          "evidence", "sources"},  # 只留已固证素材
}

TYPE_NAME = {"A": "研判报告", "B": "汇报报告", "C": "移送固证报告"}


def render_sufficiency(block: dict[str, Any]) -> str:
    cross = block.get("证据充分性", {})
    lines: list[str] = []
    level = cross.get("交叉等级")
    lines.append(f"**交叉等级**：{level or '未判定'}")
    lines.append("")
    lines.append(f"> 判定规则：{cross.get('等级规则', '单源=观察 / 双源=线索 / 三源以上=可立案依据候选')}")
    lines.append("")

    hit = cross.get("命中间类") or []
    lines.append(f"**已命中间类**：{'、'.join(hit) if hit else '（无）'}")

    gap = cross.get("覆盖缺口")
    if gap is None:
        lines.append("")
        lines.append("**覆盖缺口**：未知（内核未就绪，未能计算）")
        lines.append("")
        lines.append("> 缺口未知≠无缺口。本案五间覆盖情况未经内核复核，"
                     "不得据此认定证据链已闭合。")
    elif gap:
        lines.append("")
        lines.append(f"**覆盖缺口**：{'、'.join(gap)}")
        lines.append("")
        lines.append("> 缺口含义：上述间类在本案中尚无数据支撑，"
                     "相应方向的证据链未闭合（对抗痕迹未覆盖）。")
    else:
        lines.append("")
        lines.append("**覆盖缺口**：无（五间均已覆盖）")

    declared = cross.get("五间声明") or []
    if declared:
        lines.append("")
        lines.append("| 间类 | 权重 | 密级 | 数据源 |")
        lines.append("|------|------|------|--------|")
        for d in declared:
            lines.append(
                f"| {d.get('名称', '')} | {d.get('权重', '')} "
                f"| {d.get('密级', '')} | {'、'.join(d.get('数据源') or []) or '—'} |"
            )
    return "\n".join(lines)


def render_correlation(block: dict[str, Any]) -> str:
    corr = block.get("关联核验", {})
    lines: list[str] = []

    paths = corr.get("过桥路径") or []
    lines.append(f"**过桥路径**：{'发现 ' + str(len(paths)) + ' 条' if paths else '未发现'}")
    if paths:
        lines.append("")
        for p in paths[:20]:
            lines.append(f"- {p}")
    lines.append("")
    lines.append("> 过桥路径由图库两跳识别（Cypher 多跳 + SQL 自连接双轨），"
                 "用于识别第三方过桥结构。")

    rules = corr.get("规则手册") or []
    lines.append("")
    lines.append(f"**适用规则手册**：{len(rules)} 条")
    if rules:
        lines.append("")
        lines.append("| 规则 | 名称 | 间类 |")
        lines.append("|------|------|------|")
        for r in rules[:50]:
            jian = r.get("间类") or []
            lines.append(
                f"| {r.get('id', '')} | {r.get('名称', '')} "
                f"| {'、'.join(jian) if isinstance(jian, list) else jian or '—'} |"
            )
    return "\n".join(lines)


def build_markdown(evidence: dict, sections: dict, rtype: str) -> str:
    keep = TYPE_KEEP.get(rtype)
    degraded = evidence.get("降级") or []
    det = evidence.get("确定性块") or {}

    out: list[str] = []
    out.append(f"# {TYPE_NAME.get(rtype, '研判报告')}")
    out.append("")
    out.append(f"- 案件：{evidence.get('case_id', '')}")
    if evidence.get("clue_id"):
        out.append(f"- 线索：{evidence.get('clue_id')}")
    out.append(f"- 数据版本：v{evidence.get('data_version')}"
               if evidence.get("data_version") is not None
               else "- 数据版本：未解析")
    out.append(f"- 生成方式：{evidence.get('生成方式', 'deterministic')}")
    out.append("")

    if degraded:
        out.append("> ⚠ **降级声明**：以下能力在本案中不可用，"
                   "报告相应内容缺失或未经内核复核")
        out.append(">")
        for d in degraded:
            out.append(f"> - {d}")
        out.append("")

    if rtype == "C":
        out.append("> 本报告由 AI 整理已固证素材，**不含定性结论**。"
                   "定性权属于办案人（正兵）。")
        out.append("")

    for key, title in SECTION_TITLES:
        if keep is not None and key not in keep:
            continue
        if key == "sufficiency":
            body = render_sufficiency(det)
        elif key == "correlation":
            body = render_correlation(det)
        else:
            body = (sections.get(key) or "").strip()
        out.append(f"## {title}")
        out.append("")
        out.append(body if body else "（本段无内容）")
        out.append("")

    cites = sections.get("citations") or []
    if cites:
        out.append("## 附录：引用索引")
        out.append("")
        out.append("| 编号 | 引用 | 摘要 |")
        out.append("|------|------|------|")
        for c in cites:
            out.append(
                f"| {c.get('cite_id', '')} | {c.get('ref', '')} "
                f"| {str(c.get('summary', ''))[:60]} |"
            )
        out.append("")

    return "\n".join(out)


def build_docx(md: str, out_path: str) -> None:
    try:
        from docx import Document
    except ImportError:
        raise SystemExit(
            "未安装 python-docx，无法导出 docx。\n"
            "安装：pip install python-docx\n"
            "或改用 --format md（无需额外依赖）。"
        )
    doc = Document()
    for line in md.split("\n"):
        s = line.rstrip()
        if not s:
            continue
        if s.startswith("# "):
            doc.add_heading(s[2:], level=0)
        elif s.startswith("## "):
            doc.add_heading(s[3:], level=1)
        elif s.startswith("| "):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(set(c) <= set("-: ") for c in cells):
                continue
            row = doc.add_table(rows=1, cols=len(cells))
            for i, c in enumerate(cells):
                row.rows[0].cells[i].text = c
        elif s.startswith("> "):
            doc.add_paragraph(s[2:], style="Intense Quote")
        elif s.startswith("- "):
            doc.add_paragraph(s[2:], style="List Bullet")
        else:
            doc.add_paragraph(s)
    doc.save(out_path)


def main() -> int:
    ap = argparse.ArgumentParser(description="渲染研判报告")
    ap.add_argument("--evidence", required=True, help="gather_evidence.py 产出")
    ap.add_argument("--sections", required=True, help="Agent 撰写的叙述段 JSON")
    ap.add_argument("--type", default="A", choices=["A", "B", "C"])
    ap.add_argument("--format", default="md", choices=["md", "docx"])
    ap.add_argument("--out", default="研判报告.md")
    args = ap.parse_args()

    evidence = json.loads(Path(args.evidence).read_text(encoding="utf-8"))
    sections = json.loads(Path(args.sections).read_text(encoding="utf-8"))

    # 红线：确定性段由 evidence 渲染，忽略 sections 中的同名段
    override = [k for k in DETERMINISTIC if sections.get(k)]
    if override:
        print(f"提示：{override} 为确定性段，已忽略 sections.json 中的同名内容",
              file=__import__("sys").stderr)

    md = build_markdown(evidence, sections, args.type)
    if args.format == "docx":
        build_docx(md, args.out)
    else:
        Path(args.out).write_text(md, encoding="utf-8")
    print(f"已生成：{args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
